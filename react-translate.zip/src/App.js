import "./styles.css";
import React from "react";

export default function App() {
  return (
    <div>
      <h1 className="title">Hi there!</h1>
    </div>
  );
}
